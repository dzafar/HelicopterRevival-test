local transferralEntityName = "hr-heli-names"

heliAttack =
{
	type = "heliAttack",
	bodyOffset = 5,
	rotorOffset = 5.1,

	rotorRPFacceleration = 0.0002,
	rotorMaxRPF = 240/60/60, --revolutions per frame

	engineReduction = 7.5,

	fuelSlots = 5,

	new = function(prefix, placementEnt, bobbing)
		local baseEnt = placementEnt.surface.create_entity {name = prefix.."heli-entity-_-", force = placementEnt.force, position = placementEnt.position, quality = placementEnt.quality}

		local childs =
		{
			bodyEnt = placementEnt.surface.create_entity{name = prefix.."heli-body-entity-_-", force = game.forces.neutral, position = {x = baseEnt.position.x, y = baseEnt.position.y + heliAttack.bodyOffset}},
			rotorEnt = placementEnt.surface.create_entity{name = prefix.."rotor-entity-_-", force = game.forces.neutral, position = {x = baseEnt.position.x, y = baseEnt.position.y + heliAttack.rotorOffset}},

			bodyEntShadow = placementEnt.surface.create_entity{name = prefix.."heli-shadow-entity-_-", force = game.forces.neutral, position = baseEnt.position},
			rotorEntShadow = placementEnt.surface.create_entity{name = prefix.."rotor-shadow-entity-_-", force = game.forces.neutral, position = baseEnt.position},

			burnerEnt = placementEnt.surface.create_entity{name = prefix.."heli-burner-entity-_-", force = game.forces.neutral, position = {x = baseEnt.position.x, y = baseEnt.position.y + 1.3}},

			floodlightEnt = placementEnt.surface.create_entity{name = prefix.."heli-floodlight-entity-_-", force = game.forces.neutral, position = baseEnt.position},
		}

		return heliBase.new(prefix, placementEnt, baseEnt, childs, {__index = heliAttack}, bobbing)
	end,
}

setmetatable(heliAttack, {__index = heliBase})

local entity = prototypes.entity[transferralEntityName]
local datas
if entity ~= nil then
	_, datas = serpent.load(entity.localised_description)
end

local heliEntityNamesSuffix = {
	"heli-entity-_-",
	"heli-body-entity-_-",
	"heli-landed-collision-end-entity-_-",
	"heli-landed-collision-side-entity-_-",
	"heli-shadow-entity-_-",
	"heli-flying-collision-entity-_-",
	"heli-burner-entity-_-",
	"heli-floodlight-entity-_-",
	"rotor-entity-_-",
	"rotor-shadow-entity-_-",
}

heliEntityNames = {}
for _, data in pairs(datas) do
	for _, suffix in pairs(heliEntityNamesSuffix) do
		heliEntityNames[data.prefix..suffix] = true
	end
end

heliBaseEntityNames = {}
for _, data in pairs(datas) do
	heliBaseEntityNames[data.prefix.."heli-entity-_-"] = data.prefix
end

heliPlacementEntityNames = {}
for _, data in pairs(datas) do
	heliPlacementEntityNames[data.prefix.."helicopter"] = {prefix = data.prefix, bobbing = data.bobbing}
end
--[[
heliEntityNames = heliEntityNames .. concatStrTable({
	"heli-entity-_-",
	"heli-body-entity-_-",
	"heli-landed-collision-end-entity-_-",
	"heli-landed-collision-side-entity-_-",
	"heli-shadow-entity-_-",
	"heli-flying-collision-entity-_-",
	"heli-burner-entity-_-",
	"heli-floodlight-entity-_-",
	"rotor-entity-_-",
	"rotor-shadow-entity-_-",
}, ",")
]]

--heliBaseEntityNames = heliBaseEntityNames .. "heli-entity-_-" .. ","